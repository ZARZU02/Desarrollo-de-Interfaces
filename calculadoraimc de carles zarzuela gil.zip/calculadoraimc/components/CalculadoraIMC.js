import React, { Component } from 'react';
import { StyleSheet, View, Text, TextInput, Button, ScrollView } from 'react-native';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      peso: '',
      altura: '',
      resultado: '',
      categoria: '',
      categoriaColor: 'black',
    };
  }

  calcularIMC = () => {
    const { peso, altura } = this.state;
    const pesoNum = Number(peso);
    const alturaNum = Number(altura);

    if (pesoNum > 0 && alturaNum > 0) {
      const imc = pesoNum / (alturaNum * alturaNum);
      this.setState({ resultado: imc.toFixed(2) });

      if (imc < 18.5) {
        this.setState({ categoria: 'Peso insuficiente', categoriaColor: 'green' });
      } else if (imc < 25) {
        this.setState({ categoria: 'Normopeso', categoriaColor: 'green' });
      } else if (imc < 27) {
        this.setState({ categoria: 'Sobrepeso grado I', categoriaColor: 'green' });
      } else if (imc < 30) {
        this.setState({ categoria: 'Sobrepeso grado II (preobesidad)', categoriaColor: 'orange' });
      } else if (imc < 35) {
        this.setState({ categoria: 'Obesidad de tipo I', categoriaColor: 'orange' });
      } else if (imc < 40) {
        this.setState({ categoria: 'Obesidad de tipo II', categoriaColor: 'orange' });
      } else if (imc < 50) {
        this.setState({ categoria: 'Obesidad de tipo III (mórbida)', categoriaColor: 'red' });
      } else {
        this.setState({ categoria: 'Obesidad de tipo IV (extrema)', categoriaColor: 'red' });
      }
    } else {
      this.setState({
        resultado: '',
        categoria: 'Por favor, ingrese valores válidos',
        categoriaColor: 'red',
      });
    }
  };

  render() {
    const { peso, altura, resultado, categoria, categoriaColor } = this.state;

    return (
      <View style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <Text style={styles.title}>Calculadora IMC</Text>
          <View style={styles.card}>
            <Text style={styles.subTitle}>Datos</Text>
            <Text style={styles.label}>PESO</Text>
            <TextInput
              style={styles.input}
              keyboardType="numeric"
              placeholder="Ejemplo: 110"
              value={peso}
              onChangeText={(text) => this.setState({ peso: text })}
            />
            <Text style={styles.label}>ALTURA</Text>
            <TextInput
              style={styles.input}
              keyboardType="numeric"
              placeholder="Ejemplo: 1.85"
              value={altura}
              onChangeText={(text) => this.setState({ altura: text })}
            />
            <Button title="Calcular IMC" onPress={this.calcularIMC} />
            {resultado ? (
              <View style={styles.resultadoContainer}>
                <Text style={styles.resultado}>Resultado</Text>
                <Text style={[styles.categoria, { color: categoriaColor }]}>
                  {categoria}
                </Text>
              </View>
            ) : null}
          </View>
          <Text style={styles.footer}>Created for 2n DAM</Text>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'purple',
  },
  scrollContent: {
    alignItems: 'center',
    padding: 16,
  },
  title: {
    color: 'red',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 24,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    width: '100%',
    maxWidth: 400,
    shadowColor: 'black',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 5,
  },
  subTitle: {
    color: 'red',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  label: {
    color: 'blue',
    fontSize: 16,
    marginTop: 8,
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    marginBottom: 12,
    paddingVertical: 4,
    fontSize: 16,
  },
  resultadoContainer: {
    marginTop: 16,
    alignItems: 'flex-start',
  },
  resultado: {
    fontSize: 16,
  },
  categoria: {
    fontWeight: 'bold',
    marginTop: 8,
  },
  footer: {
    marginTop: 16,
    color: 'lightgray',
    fontSize: 12,
    textAlign: 'center',
  },
});

export default App;
