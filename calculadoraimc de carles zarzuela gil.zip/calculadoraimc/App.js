import { SafeAreaView, StyleSheet } from 'react-native';
import AssetExample from './components/CalculadoraIMC';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <AssetExample />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, // Ocupa toda la pantalla
    backgroundColor: 'purple', // Fondo morado
  },
});
